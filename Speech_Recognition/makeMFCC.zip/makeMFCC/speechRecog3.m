%-----------SPEECH RECOGNITION USING BACK PROPAGATION ALGORITHM----------%
% This code solves the problem of speech recognition using Back
% Propagation Algorithm. 
%------------------------------Code Starts-------------------------------%
clc; clear all; close all;
% Test speech file
testFile = 'M12S1';
fprintf('Test File: [%s]\n',testFile);
% Reference speech file 
refFile =   ['M12S1';'M12S2';'M12S3';'M12S4';'M12S5';'M12S6';...
             'M13S1';'M13S2';'M13S3';'M13S4';'M13S5';'M13S6';...
             'M14S1';'M14S2';'M14S3';'M14S4';'M14S5';'M14S6'];
NO2 = length(refFile);
fprintf('No. of Ref File: %d\n',NO2);

%------------------------------------------%    
% Ref Speech Data and Features Extraction  %
%------------------------------------------%
%Ref-1
[a01, N(1)] = featureExtract(refFile(1,:));
%Ref-2
[a02, N(2)] = featureExtract(refFile(2,:));
%Ref-3
[a03, N(3)] = featureExtract(refFile(3,:));
%Ref-4
[a04, N(4)] = featureExtract(refFile(4,:));
%Ref-5
[a05, N(5)] = featureExtract(refFile(5,:));
%Ref-6
[a06, N(6)] = featureExtract(refFile(6,:));
%Ref-7
[a07, N(7)] = featureExtract(refFile(7,:));
%Ref-8
[a08, N(8)] = featureExtract(refFile(8,:));
%Ref-9
[a09, N(9)] = featureExtract(refFile(9,:));
%Ref-10
[a10,N(10)]= featureExtract(refFile(10,:));
%Ref-11
[a11,N(11)]= featureExtract(refFile(11,:));
%Ref-12
[a12,N(12)]= featureExtract(refFile(12,:));
[a13,N(13)]= featureExtract(refFile(13,:));
[a14,N(14)]= featureExtract(refFile(14,:));
[a15,N(15)]= featureExtract(refFile(15,:));
[a16,N(16)]= featureExtract(refFile(16,:));
[a17,N(17)]= featureExtract(refFile(17,:));
[a18,N(18)]= featureExtract(refFile(18,:));
% Test Speech Data
[td,N(19)] = featureExtract(testFile);
% Zero padding
maxN = N(1)
% for i=2:NO+1
%     if maxN <N(i) 
%         maxN = N(i);
%     end
% end
% a1 = zeropadding(a01,N(1),maxN);
% b1 = zeropadding(a02,N(2),maxN);
% c1 = zeropadding(a03,N(3),maxN);
% d1 = zeropadding(a04,N(4),maxN);
% e1 = zeropadding(a05,N(5),maxN);
% f1 = zeropadding(a06,N(6),maxN);
% g1 = zeropadding(a07,N(7),maxN);
% h1 = zeropadding(a08,N(8),maxN);
% i1 = zeropadding(a09,N(9),maxN);
% j1 = zeropadding(a10,N(10),maxN);
% k1 = zeropadding(a11,N(11),maxN);
% l1 = zeropadding(a12,N(12),maxN);
% td = zeropadding(aa,N(13),maxN); % Test data
%----------------------------Training------------------------%
p=[a01 a02 a03 a04 a05 a06 a07 a08 a09 a10 a11 a12 a13 a14 a15 a16 a17 a18];
t=eye(6); % eye(n) returns the n-by-n identity matrix.
        % New feedforward net
        % [x,t] = simplefit_dataset;
        % net = feedforwardnet(10)
        % net = train(net,x,t);
        % view(net)
        % y = net(x);
        % perf = perform(net,y,t)

        % net = feedforwardnet(40, 'trainlm')
        % net = train(net,p,t);
        % Y = net(p);

%net=newff(minmax(le),[15,12],{'tansig','purelin'},'traingd');
net = newff(minmax(p),[40,6],{'tansig','purelin'},'traingd');
%net.trainParam.epochs = 1000;
% net.trainParam.show = 100;
% net.trainParam.goal=0.001;
% net.trainParam.lr=0.01;
% net.trainParam.mc=0.9
net = train(net,p,t);
Y = sim(net,p)

cor=0;
NO = 6;
for i=1:NO
    max=1;
    for j=1:NO
        if Y(j,i)>Y(max,i)
            max=i;
        end
    end
    if max==i
        cor=cor+1;
    end
end

%'Train Cases Recognized'
%cor
fprintf('Train Cases Recognition Accuracy: %f\n',cor/6*100);
%----------------------------End Traning----------------------------%
%
%------------------------------Testing------------------------------%
k = 'Y';
while(isequal(k,'Y')|isequal(k,'y'))
    name = input('Enter file name: ', 's');

    [td,N] = featureExtract(name);
    out=sim(net,td); 

    fprintf('Test speech output vector:\n');
    fprintf('%f\n',out);

    max=1;
    for j=1:NO
        if out(j)>out(max)
            max=j;
        end
    end

    fprintf('Test File: [%s.wav]\n',name);
    fprintf('Test speech matching output: %d\n',max);
    k = input('Try again (Y/N)? ','s');
end
%--------------------------End Testing------------------------------%