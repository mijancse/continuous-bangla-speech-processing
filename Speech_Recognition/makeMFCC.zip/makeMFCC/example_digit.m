%-----------SPEECH RECOGNITION USING BACK PROPAGATION ALGORITHM----------%
clc; clear all; close all;
%----------------------------Training------------------------%
le0=[1 1 1 1 1 1 0 0 0 1 1 0 0 0 1 1 0 0 0 1 1 1 1 1 1]';
le1=[0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0]';
le2=[1 1 1 1 1 0 0 0 0 1 1 1 1 1 1 1 0 0 0 0 1 1 1 1 1]';
le3=[1 1 1 1 1 0 0 0 0 1 1 1 1 1 1 0 0 0 0 1 1 1 1 1 1]';
le4=[1 0 0 0 1 1 0 0 0 1 1 1 1 1 1 0 0 0 0 1 0 0 0 0 1]';
le5=[1 1 1 1 1 1 0 0 0 0 1 1 1 1 1 0 0 0 0 1 1 1 1 1 1]';
le6=[1 1 1 1 1 1 0 0 0 0 1 1 1 1 1 1 0 0 0 1 1 1 1 1 1]';
le7=[1 1 1 1 1 0 0 0 1 0 0 0 1 0 0 0 1 0 0 0 1 0 0 0 0]';
le8=[1 1 1 1 1 1 0 0 0 1 1 1 1 1 1 1 0 0 0 1 1 1 1 1 1]';
le9=[1 1 1 1 1 1 0 0 0 1 1 1 1 1 1 0 0 0 0 1 1 1 1 1 1]';

P=[le0,le1,le2,le3,le4,le5,le6,le7,le8,le9];
T=[0 0 0 0;...
   0 0 0 1;...
   0 0 1 0;...
   0 0 1 1;...
   0 1 0 0;...
   0 1 0 1;...
   0 1 1 0;...
   0 1 1 1;...
   1 0 0 0;...
   1 0 0 1]';
%adopting feedforward BP network algorithm %and the BP algorithm training function %Levenberg_Marquardt
net=newff(minmax(P),[10,4],{'logsig','logsig'},'trainlm');
%the biggest training times is 5000 here net.trainParam.epochs=5000;
net.trainParam.goal=0.1;
net.trainParam.lr=0.01;
net.trainParam.mm=0.95;
net.trainParam.er=1.05
net=train(net,P,T);

Y = sim(net,P);
% Test Speech Data

td = le9;

out=sim(net,td); 

    fprintf('Test output vector:\n');
    fprintf('%f\n',out);

    max=1;
    for j=1:4
        if out(j)>out(max)
            max=j;
        end
    end

    fprintf('Test matching output: %d\n',max);
%--------------------------End Testing------------------------------%