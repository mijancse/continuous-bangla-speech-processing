%-----------SPEECH RECOGNITION USING BACK PROPAGATION ALGORITHM----------%
% This code solves the problem of speech recognition using Feedforward 
% Neural Network with Back Propagation Algorithm. 
%------------------------------Code Starts-------------------------------%
clc; clear all; close all;
% Test speech file
% testFile = 'M41S1';
% fprintf('Test File: [%s]\n',testFile);

% Reference speech file 
NO = 5;     % Number of sample words
refFile =   ['M41S1';'M41S2';'M41S3';'M41S4';'M41S5';...
             'M43S1';'M43S2';'M43S3';'M43S4';'M43S5';...
             'M45S1';'M45S2';'M45S3';'M45S4';'M45S5'];
NO2 = length(refFile); % Total number of samples
fprintf('No. of Ref File: %d\n',NO2);
%
%-------------------%%Speech Data and Features Extraction%%--------------%
% Number of MFCC data
%Ref-1
a01 = featureExtract(refFile(1,:));
%Ref-2
a02 = featureExtract(refFile(2,:));
%Ref-3
a03 = featureExtract(refFile(3,:));
%Ref-4
a04 = featureExtract(refFile(4,:));
%Ref-5
a05 = featureExtract(refFile(5,:));
%Ref-6
b01 = featureExtract(refFile(6,:));
%Ref-7
b02 = featureExtract(refFile(7,:));
%Ref-8
b03 = featureExtract(refFile(8,:));
%Ref-9
b04 = featureExtract(refFile(9,:));
%Ref-10
b05 = featureExtract(refFile(10,:));
%Ref-11
c01 = featureExtract(refFile(11,:));
%Ref-12
c02 = featureExtract(refFile(12,:));
%Ref-13
c03 = featureExtract(refFile(13,:));
%Ref-14
c04 = featureExtract(refFile(14,:));
%Ref-15
c05 = featureExtract(refFile(15,:));
%
%----------------------------%%Training Phase%%------------------------%
p = [a01,a02,a03,a04,a05,b01,b02,b03,b04,b05,c01,c02,c03,c04,c05];
t=[eye(5) eye(5) eye(5)]; % eye(n) returns the n-by-n identity matrix.
% t=[1 0 0 0 0;...
%    0 1 0 0 0;...
%    0 0 1 0 0;...
%    0 0 0 1 0;...
%    0 0 0 0 1';...
%    1 0 0 0 0;...
%    0 1 0 0 0;...
%    0 0 1 0 0;...
%    0 0 0 1 0;...
%    0 0 0 0 1';...
%    1 0 0 0 0;...
%    0 1 0 0 0;...
%    0 0 1 0 0;...
%    0 0 0 1 0;...
%    0 0 0 0 1]';
% net=newff(minmax(le),[15,12],{'tansig','purelin'},'traingd');
net = newff(minmax(p),[10,NO],{'tansig','purelin'},'traingd');
% net.trainParam.epochs = 1000;
% net.trainParam.show = 100;
net.trainParam.goal=0.1;
% net.trainParam.lr=0.01;
% net.trainParam.mc=0.9
net = train(net,p,t);
Y = sim(net,p);

% % cor=0;
% % for i=1:NO
% %     max=1;
% %     for j=1:NO
% %         if Y(j,i)>Y(max,i)
% %             max=i;
% %         end
% %     end
% %     if max==i
% %         cor=cor+1;
% %     end
% % end
% % fprintf('Train Cases Recognition Accuracy: %f\n',cor/6*100);

%--------------------------%%End Traning Phase%%--------------------------%
%
%--------------------------%%Testing Phase%%------------------------------%
k = 'Y';
while(isequal(k,'Y')|isequal(k,'y'))
    testFileName = input('Enter file name: ', 's');

    % Test Speech Data
    td = featureExtract(testFileName);
    out=sim(net,td); 

    fprintf('Test speech output vector:\n');
    fprintf('%f\n',out);

    max=1;
    for j=1:NO
        if out(j)>out(max)
            max=j;
        end
    end

    fprintf('Test File: [%s.wav]\n',testFileName);
    fprintf('Test speech matching output: %d\n',max);
    k = input('Try again (Y/N)? ','s');
end
%--------------------------%%End Testing Phase%%--------------------------%