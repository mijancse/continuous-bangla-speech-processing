% Speech Spectrogram + MFCC
clc; clear all; close all;
File = 'M12S6'; % Input speech file
testFile = [File '.wav'];
spectFile = 'Spectrogram.png';
fprintf('Test File: [%s]\n',testFile);
[ speech, fs, nbits ] = wavread(testFile);
sample=endpt(speech);
%Spectrogram
h = myspectrogram(sample, fs, [22 1], @hamming, 2048, [-59 -1], false, 'default', false, 'per'); % or be quite specific about what you want
% title('Speech Spectrogram');
%xlabel('Time (s)');
%ylabel('Frequency (Hz)');
set(gca,'position',[0 0 1 1],'units','normalized')
axis off;
print('-dpng', spectFile);
I = imread(spectFile); % Read spectrogram image
I = imread(spectFile); % Read image file
im= imresize(I, 0.1);  % Resize image

fim = mat2gray(im);
max(fim)
[m,n,d]=size(fim)
%MFCC
mfccData = mfcc2(sample,fs);
N = length(mfccData)
%EOF