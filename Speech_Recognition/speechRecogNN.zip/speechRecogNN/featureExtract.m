function mfccData = featureExtract(fileName,nM)
if nargin < 2   nM = 128;    end

wavFile = [fileName '.wav'];
fprintf('Processing [%s]...\n',wavFile);
[ speech, fs, nbits ] = wavread(wavFile);
sample=endpt(speech);
mfccData = mfcc2(sample,fs,nM);
%EOF