function data = zeropadding(x,N,maxN)
y = x;
if  N<maxN 
    for i=N+1:maxN
        y = [y;0.0];
    end
end
data = y;