%-----------SPEECH MFCC FEATURES EXTRACTON----------%
clc; clear all; close all;
% Test speech file
File = 'M15S2'; % Input speech file
out1 = fopen([File '_MFCC.txt'],'w'); 
testFile = [File '.wav'];
fprintf('Test File: [%s]\n',testFile);
[ speech, fs, nbits ] = wavread(testFile);
subplot(311);
plot(speech);
xlabel( 'Sample (s)' ); 
ylabel( 'Amplitude' ); 
title( 'Speech waveform'); 
% End-point detection
sample=endpt(speech);
subplot(312);
plot(sample);
xlabel( 'Sample (s)' ); 
ylabel( 'Amplitude' ); 
title( 'Speech waveform after end-point detection'); 

% Get Mel-Cepstrum coefficients for input wav file
s = mfcc2(sample,fs);
fprintf(out1,'%f\n',s);
fclose(out1);
size(s)
subplot(313);
plot(s);
xlabel( 'Sample (s)'); 
ylabel( 'Cepstrum' );
title( 'Mel frequency cepstrum' );
% Set color map to grayscale
%colormap( 1-colormap('gray') ); 
print('-dpng', sprintf([File '_Spect.png']));
%--------------------------End Testing------------------------------%