%-----------SPEECH RECOGNITION USING BACK PROPAGATION ALGORITHM----------%
% This code solves the problem of speech recognition using Feedforward 
% Neural Network with Back Propagation Algorithm. 
%------------------------------Code Starts-------------------------------%
clc; clear all; close all;
% Test speech file
% testFile = 'M41S1';
% fprintf('Test File: [%s]\n',testFile);

% Reference speech file 
N = 9;     % Number of sample words
refFile=['M1S1';'M1S2';'M1S3';'M1S4';'M1S5';'M1S6';'M1S7';'M1S8';...
'M1S9';'M3S1';'M3S2';'M3S3';'M3S4';'M3S5';'M3S6';'M3S7';'M3S8';...
'M3S9';'M5S1';'M5S2';'M5S3';'M5S4';'M5S5';'M5S6';'M5S7';'M5S8';...
'M5S9';'M7S1';'M7S2';'M7S3';'M7S4';'M7S5';'M7S6';'M7S7';'M7S8';...
'M7S9';'M9S1';'M9S2';'M9S3';'M9S4';'M9S5';'M9S6';'M9S7';'M9S8';...
'M9S9'];

% ;'M11S1';'M11S2';'M11S3';'M11S4';'M11S5';'M11S6';'M11S7';...
% 'M11S8';'M11S9';'M11S10';'M13S1';'M13S2';'M13S3';'M13S4';'M13S5';...
% 'M13S6';'M13S7';'M13S8';'M13S9';'M13S10';'M15S1';'M15S2';'M15S3';...
% 'M15S4';'M15S5';'M15S6';'M15S7';'M15S8';'M15S9';'M15S10';'M17S1';...
% 'M17S2';'M17S3';'M17S4';'M17S5';'M17S6';'M17S7';'M17S8';'M17S9';...
% 'M17S10';'M19S1';'M19S2';'M19S3';'M19S4';'M19S5';'M19S6';'M19S7';...
% 'M19S8';'M19S9';'M19S10'];
nR = length(refFile); % Total number of samples
fprintf('No. of Ref File: %d\n',nR);
%
%-------------------%%Speech Data and Features Extraction%%--------------%
% Number of MFCC data
nM = 128;
% mfccdata = [];
% for i = 1:nR
%     data = featureExtract(refFile(i,:),nM);
%     mfccdata = [mfccdata;data];
% end
% Ref mfcc data
a01 = featureExtract(refFile(1,:),nM);
a02 = featureExtract(refFile(2,:),nM);
a03 = featureExtract(refFile(3,:),nM);
a04 = featureExtract(refFile(4,:),nM);
a05 = featureExtract(refFile(5,:),nM);
a06 = featureExtract(refFile(6,:),nM);
a07 = featureExtract(refFile(7,:),nM);
a08 = featureExtract(refFile(8,:),nM);
a09 = featureExtract(refFile(9,:),nM);
%a10 = featureExtract(refFile(10,:),nM);
%
b01 = featureExtract(refFile(10,:),nM);
b02 = featureExtract(refFile(11,:),nM);
b03 = featureExtract(refFile(12,:),nM);
b04 = featureExtract(refFile(13,:),nM);
b05 = featureExtract(refFile(14,:),nM);
b06 = featureExtract(refFile(15,:),nM);
b07 = featureExtract(refFile(16,:),nM);
b08 = featureExtract(refFile(17,:),nM);
b09 = featureExtract(refFile(18,:),nM);
%b10 = featureExtract(refFile(20,:),nM);
%
c01 = featureExtract(refFile(19,:),nM);
c02 = featureExtract(refFile(20,:),nM);
c03 = featureExtract(refFile(21,:),nM);
c04 = featureExtract(refFile(22,:),nM);
c05 = featureExtract(refFile(23,:),nM);
c06 = featureExtract(refFile(24,:),nM);
c07 = featureExtract(refFile(25,:),nM);
c08 = featureExtract(refFile(26,:),nM);
c09 = featureExtract(refFile(27,:),nM);
%c10 = featureExtract(refFile(30,:),nM);
%
d01 = featureExtract(refFile(28,:),nM);
d02 = featureExtract(refFile(29,:),nM);
d03 = featureExtract(refFile(30,:),nM);
d04 = featureExtract(refFile(31,:),nM);
d05 = featureExtract(refFile(32,:),nM);
d06 = featureExtract(refFile(33,:),nM);
d07 = featureExtract(refFile(34,:),nM);
d08 = featureExtract(refFile(35,:),nM);
d09 = featureExtract(refFile(36,:),nM);
%d10 = featureExtract(refFile(40,:),nM);
%
e01 = featureExtract(refFile(37,:),nM);
e02 = featureExtract(refFile(38,:),nM);
e03 = featureExtract(refFile(39,:),nM);
e04 = featureExtract(refFile(40,:),nM);
e05 = featureExtract(refFile(41,:),nM);
e06 = featureExtract(refFile(42,:),nM);
e07 = featureExtract(refFile(43,:),nM);
e08 = featureExtract(refFile(44,:),nM);
e09 = featureExtract(refFile(45,:),nM);
%e10 = featureExtract(refFile(50,:),nM);
%
%----------------------------%%Training Phase%%------------------------%
p = [a01,a02,a03,a04,a05,a06,a07,a08,a09,...
     b01,b02,b03,b04,b05,b06,b07,b08,b09,...
     c01,c02,c03,c04,c05,c06,c07,c08,c09,...
     d01,d02,d03,d04,d05,d06,d07,d08,d09,...
     e01,e02,e03,e04,e05,e06,e07,e08,e09];
t=[eye(9) eye(9) eye(9) eye(9) eye(9)]; % eye(n) returns the n-by-n identity matrix.
[Pr,Pc] = size(p);
[Tr,Tc] = size(t);
nH = floor(0.5*Pr);
nO = Tr;
Pr
Pc
nH
Tr
for i=1:1:3
% net = newff(minmax(p),[40,N],{'tansig','purelin'},'traingd');
net = newff(minmax(p),[nH,nO],{'tansig','purelin'},'traingd');
% net.trainParam.epochs = 2000;
% net.trainParam.show = 100;
% net.trainParam.goal=0.1;
% net.trainParam.lr=0.01;
% net.trainParam.mc=0.9
net = train(net,p,t);
y = sim(net,p);
%y
% Accuracy
e = y-t;
rmse = sqrt(mse(e));
acc = 1-rmse;
acc
end
% % cor=0;
% % for i=1:N
% %     max=1;
% %     for j=1:N
% %         if y(j,i)>y(max,i)
% %             max=i;
% %         end
% %     end
% %     if max==i
% %         cor=cor+1;
% %     end
% % end
% % fprintf('Train Cases Recognition Accuracy: %f\n',cor/6*100);

%--------------------------%%End Traning Phase%%--------------------------%
%
%--------------------------%%Testing Phase%%------------------------------%
k = 'Y';
while(isequal(k,'Y')|isequal(k,'y'))
    testFileName = input('Enter file name: ', 's');

    % Test Speech Data
    td = featureExtract(testFileName,nM);
    out=sim(net,td); 

    fprintf('Test speech output vector:\n');
    fprintf('%f\n',out);

    max=1;
    for j=1:N
        if out(j)>out(max)
            max=j;
        end
    end

    fprintf('Test File: [%s.wav]\n',testFileName);
    fprintf('Test speech matching output: %d\n',max);
    k = input('Try again (Y/N)? ','s');
end
%--------------------------%%End Testing Phase%%--------------------------%