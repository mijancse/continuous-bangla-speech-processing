%-----------SPEECH RECOGNITION USING BACK PROPAGATION ALGORITHM----------%
% This code solves the problem of speech recognition using Back
% Propagation Algorithm. 
%------------------------------Code Starts-------------------------------%
clc; clear all; close all;
% Test speech file
testFile = 'M15S5.wav';
fprintf('Test File: [%s]\n',testFile);
% Reference speech file 
refFile = ['M12S1';'M12S2';'M12S3';'M12S4';'M12S5'];
NO = length(refFile);
fprintf('No. of Ref File: %d\n',NO);
%
%------------------------------------------%
% Test Speech Data and Feature Extraction  %
%------------------------------------------%
[ speech, fs, nbits ] = wavread(testFile);
sample=endpt(speech);
testData = mfcc(sample,fs);
%------------------------------------------%    
% Ref Speech Data and Features Extraction  %
%------------------------------------------%

%Ref-1
fileName = refFile(1,:);  
wavFile = [fileName '.wav'];
fprintf('Processing [%s]...\n',wavFile);
[ speech, fs, nbits ] = wavread(wavFile);
sample=endpt(speech);
a1 = mfcc(sample,fs);

%Ref-2
fileName = refFile(2,:);  
wavFile = [fileName '.wav'];
fprintf('Processing [%s]...\n',wavFile);
[ speech, fs, nbits ] = wavread(wavFile);
sample=endpt(speech);
b1 = mfcc(sample,fs);


%Ref-3
fileName = refFile(3,:);  
wavFile = [fileName '.wav'];
fprintf('Processing [%s]...\n',wavFile);
[ speech, fs, nbits ] = wavread(wavFile);
sample=endpt(speech);
c1 = mfcc(sample,fs);

%Ref-4
fileName = refFile(4,:);  
wavFile = [fileName '.wav'];
fprintf('Processing [%s]...\n',wavFile);
[ speech, fs, nbits ] = wavread(wavFile);
sample=endpt(speech);
d1 = mfcc(sample,fs);

%Ref-5
fileName = refFile(5,:);  
wavFile = [fileName '.wav'];
fprintf('Processing [%s]...\n',wavFile);
[ speech, fs, nbits ] = wavread(wavFile);
sample=endpt(speech);
e1 = mfcc(sample,fs);
% Zero padding
N(1) = length(a1);
N(2) = length(b1);
N(3) = length(c1);
N(4) = length(d1);
N(5) = length(e1);
N(6) = length(testData);

maxN = N(1);
for i=2:NO+1
    if maxN <N(i) 
        maxN = N(i);
    end
end
maxN
if  N(1)<maxN 
    for i=N(1)+1:maxN
        a1 = [a1;0.0];
    end
end
if  N(2)<maxN 
    for i=N(2)+1:maxN
        b1 = [b1;0.0];
    end
end
if  N(3)<maxN 
    for i=N(3)+1:maxN
        c1 = [c1;0.0];
    end
end
if  N(4)<maxN 
    for i=N(4)+1:maxN
        d1 = [d1;0.0];
    end
end
if  N(5)<maxN 
    for i=N(5)+1:maxN
        e1 = [e1;0.0];
    end
end
if  N(6)<maxN 
    for i=N(6)+1:maxN
        testData = [testData;0.0];
    end
end

%----------------------------Training-----------------------%
le=[a1 b1 c1 d1 e1];
t=eye(5); % eye(n) returns the n-by-n identity matrix.
net=newff(minmax(le),[15,5],{'tansig','purelin'},'traingd');
 net.trainParam.epochs = 500;
% net.trainParam.show = 100;
net.trainParam.goal=0.001;
% net.trainParam.lr=0.01;
% net.trainParam.mc=0.9
net = train(net,le,t);
Y = sim(net,le);
cor=0;


for i=1:5
    max=1;
    for j=1:5
        if Y(j,i)>Y(max,i)
            max=i;
        end
    end
    if max==i
        cor=cor+1;
    end
end

%'Train Cases Recognized'
%cor

%'Train Cases Recognition Accuracy'
%cor/5*100
%----------------------------End Traning----------------------------%
%
%------------------------------Testing------------------------------%
out=sim(net,testData);
fprintf('Test File: [%s]\n',testFile);
fprintf('Test speech output vector:\n');
fprintf('%f\n',out);

max=1;
for j=1:NO
    if out(j)>out(max)
        max=j;
    end
end
fprintf('\nTest speech matching output: %d\n',max);
%--------------------------End Testing------------------------------%