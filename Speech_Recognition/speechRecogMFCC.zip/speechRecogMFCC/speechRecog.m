%------------SPEECH RECOGNITION USING MFCC FEATURES AND DTW------------%
clc; clear all; close all;
% Test speech file
testFile = 'M03S01.wav';
fprintf('Test File: [%s]\n',testFile);
% Reference speech file
refFile=['M01S01';'M01S02';'M01S03';'M01S04';'M01S05';'M01S06';'M01S07';'M01S08';'M01S09';'M01S10'];
         %'M02S01';'M02S02';'M02S03';'M02S04';'M02S05';'M02S06';'M02S07';'M02S08';'M02S09';'M02S10';...
         %'M03S01';'M03S02';'M03S03';'M03S04';'M03S05';'M03S06';'M03S07';'M03S08';'M03S09';'M03S10';...
         %'M04S01';'M04S02';'M04S03';'M04S04';'M04S05';'M04S06';'M04S07';'M04S08';'M04S09';'M04S10';...
         %'M05S01';'M05S02';'M05S03';'M05S04';'M05S05';'M05S06';'M05S07';'M05S08';'M05S09';'M05S10';...
         %'M06S01';'M06S02';'M06S03';'M06S04';'M06S05';'M06S06';'M06S07';'M06S08';'M06S09';'M06S10'];
         %'M07S01';'M07S02';'M07S03';'M07S04';'M07S05';'M07S06';'M07S07';'M07S08';'M07S09';'M07S10'];
         %'M08S01';'M08S02';'M08S03';'M08S04';'M08S05';'M08S06';'M08S07';'M08S08';'M08S09';'M08S10'];
         %'M09S01';'M09S02';'M09S03';'M09S04';'M09S05';'M09S06';'M09S07';'M09S08';'M09S09';'M09S10'];
         %'M10S01';'M10S02';'M10S03';'M10S04';'M10S05';'M10S06';'M10S07';'M10S08';'M10S09';'M10S10'];

NO = length(refFile);
fprintf('No. of Ref File: %d\n',NO);
%
% Feature Extraction  %
% Get Mel-Cepstrum coefficients for all referenced words
wavFile  = [refFile(1,:) '.wav'];
s1 = melcep(wavFile);
wavFile  = [refFile(2,:) '.wav'];
s2 = melcep(wavFile);
wavFile  = [refFile(3,:) '.wav'];
s3 = melcep(wavFile);
wavFile  = [refFile(4,:) '.wav'];
s4 = melcep(wavFile);
wavFile  = [refFile(5,:) '.wav'];
s5 = melcep(wavFile);
wavFile  = [refFile(6,:) '.wav'];
s6 = melcep(wavFile);
wavFile  = [refFile(7,:) '.wav'];
s7 = melcep(wavFile);
wavFile  = [refFile(8,:) '.wav'];
s8 = melcep(wavFile);
wavFile  = [refFile(9,:) '.wav'];
s9 = melcep(wavFile);
wavFile  = [refFile(10,:) '.wav'];
s10 = melcep(wavFile);

% Get Mel-Cepstrum coefficients for input wav file
s = melcep(testFile);
%length(s)
dtwS1=dtwarp(s,s1)/1000;
dtwS2=dtwarp(s,s2)/1000;
dtwS3=dtwarp(s,s3)/1000;
dtwS4=dtwarp(s,s4)/1000;
dtwS5=dtwarp(s,s5)/1000;
dtwS6=dtwarp(s,s6)/1000;
dtwS7=dtwarp(s,s7)/1000;
dtwS8=dtwarp(s,s8)/1000;
dtwS9=dtwarp(s,s9)/1000;
dtwS10=dtwarp(s,s10)/1000;

% Find the recognized word
[minS,I] = min([dtwS1 dtwS2 dtwS3 dtwS4 dtwS5 dtwS6 dtwS7 dtwS8 dtwS9 dtwS10]);
fprintf('Recognized Word: %d\n',I);
%--------------------------End Testing------------------------------%