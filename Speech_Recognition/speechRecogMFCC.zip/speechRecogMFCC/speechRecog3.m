%------------SPEECH RECOGNITION USING MFCC FEATURES AND DTW------------%
clc; clear all; close all;
% Test speech file
% testFile = 'M07S01.wav';
% Reference speech file
refFile=['M01S01';'M01S02';'M01S03';'M01S04';'M01S05';'M01S06';'M01S07';'M01S08';'M01S09';'M01S10';...
         %'M02S01';'M02S02';'M02S03';'M02S04';'M02S05';'M02S06';'M02S07';'M02S08';'M02S09';'M02S10';...
         %'M03S01';'M03S02';'M03S03';'M03S04';'M03S05';'M03S06';'M03S07';'M03S08';'M03S09';'M03S10';...
         %'M04S01';'M04S02';'M04S03';'M04S04';'M04S05';'M04S06';'M04S07';'M04S08';'M04S09';'M04S10';...
         %'M05S01';'M05S02';'M05S03';'M05S04';'M05S05';'M05S06';'M05S07';'M05S08';'M05S09';'M05S10';...
         'M06S01';'M06S02';'M06S03';'M06S04';'M06S05';'M06S06';'M06S07';'M06S08';'M06S09';'M06S10'];
         %'M07S01';'M07S02';'M07S03';'M07S04';'M07S05';'M07S06';'M07S07';'M07S08';'M07S09';'M07S10'];
         %'M08S01';'M08S02';'M08S03';'M08S04';'M08S05';'M08S06';'M08S07';'M08S08';'M08S09';'M08S10'];
         %'M09S01';'M09S02';'M09S03';'M09S04';'M09S05';'M09S06';'M09S07';'M09S08';'M09S09';'M09S10'];
         %'M10S01';'M10S02';'M10S03';'M10S04';'M10S05';'M10S06';'M10S07';'M10S08';'M10S09';'M10S10'];

nR = length(refFile);
fprintf('No. of Ref File: %d\n',nR);
%
% Feature Extraction  %
% Get Mel-Cepstrum coefficients for all referenced words
fprintf('Testing 10 words...\n');
fprintf('Result <T,O>: ');
T = 1;
acc = 0;
for j = nR-9:nR
    testFile = [refFile(j,:) '.wav'];
    mfccTest = melcep(testFile);
    for i = 1:nR-10
        wavFile = [refFile(i,:) '.wav'];
        %fprintf('Processing[%s]...\n',wavFile);
        mfccRef = melcep(wavFile);
        d = dtwarp(mfccTest,mfccRef)/1000;
        disV(:,i) = d;
    end
    [minS,I] = min(disV);
    if I>10
        I = mod(I,10);
        if I == 0
            I = 10;
        end
    end
    fprintf('<%d,%d> ',T,I);
    % Accuracy 
    if I == T
        acc = acc+1;
    end
    T=T+1;
end
fprintf('\nAccuracy = %f\n',acc*10);
%--------------------------End Testing------------------------------%