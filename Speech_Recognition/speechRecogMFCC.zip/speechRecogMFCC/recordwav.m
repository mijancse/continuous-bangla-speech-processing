% Speech Recording
clear all; clc;

x = 0;
while x ~= 5
    disp('Select your choice: 1)Record  2)Save  3)Play  4)Waveform  5)Exit');
    %Fs = 11025;
    Fs = 8000;  % Sample frequency
    Ti = 10;     % Recording time
    x = input('Enter your choice: ');
    if(x == 1)
        disp('Recording...');
        disp(Ti);
        y = wavrecord(Ti*Fs,Fs,'int16');
        
    elseif(x == 2)
        filename = input('Enter file name (name.wav): ');
        wavwrite(y,Fs,filename);
                
    elseif (x == 3)
        disp('Playing...');
        wavplay(y,Fs);
        
    elseif(x == 4)
        plot(y);
        title('Original Signal');
    end
end     
